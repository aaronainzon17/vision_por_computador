En la entrega se incluye un script cmake.sh el cual compila en una carpeta 
build el programa.

Se ha realizado el video opcional, sin embargo, debido a las restricciones de tamaño de moodle 
no se ha podido incluir en la entrega, se adjunta link de google drive donde se puede ver:
https://drive.google.com/file/d/10Km5leqbJW2NV87M5MmAyAi73ROVUcND/view?usp=sharing